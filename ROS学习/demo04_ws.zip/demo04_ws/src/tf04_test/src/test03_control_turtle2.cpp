/*

需求:
    现有坐标系统，父级坐标系统 world,下有两子级系统 son1，son2，
    son1 相对于 world，以及 son2 相对于 world 的关系是已知的，
    求 son1 与 son2 的坐标关系，又已知在 son1 中一点的坐标,求出该点在 son2 中的坐标
实现流程:
    1.包含头文件
    2.初始化 ros 节点
    3.创建 ros 句柄
    4.创建 TF 订阅对象
    5.解析订阅信息中获取 son1 坐标系原点在 son2 中的坐标
      解析 son1 中的点相对于 son2 的坐标
    6.spin

*/


/* 

新需求：
1.换算出 turtle1 相对于 turtle2 的关系
2.计算出角速度和线速度并发布

*/

//1.包含头文件
#include "ros/ros.h"
#include "tf2_ros/transform_listener.h"
#include "tf2/LinearMath/Quaternion.h"
#include "tf2_geometry_msgs/tf2_geometry_msgs.h"
#include "geometry_msgs/TransformStamped.h"
#include "geometry_msgs/PointStamped.h"
#include "geometry_msgs/Twist.h"

int main(int argc, char *argv[])
{   //防止中文乱码
    setlocale(LC_ALL,"");
    // 2.初始化 ros 节点
    ros::init(argc,argv,"sub_frames");
    // 3.创建 ros 句柄
    ros::NodeHandle nh;

    // 4.创建 TF 订阅对象
    tf2_ros::Buffer buffer; 
    tf2_ros::TransformListener listener(buffer);

    // A.创建发布对象
    ros::Publisher pub = nh.advertise<geometry_msgs::Twist>("/turtle2/cmd_vel",100);

    // 5.解析订阅信息中获取 son1 坐标系原点在 son2 中的坐标
    ros::Rate r(10);
    while (ros::ok())
    {
        try
        {
        //   计算 turtle1 与 turtle2 的相对关系 
            geometry_msgs::TransformStamped tfs = buffer.lookupTransform("turtle2","turtle1",ros::Time(0));//转换函数
                                                                    //目标坐标系，源坐标系，查找最近时间的两个坐标系关系帧
           /*  ROS_INFO("父坐标系ID = %s",tfs.header.frame_id.c_str());//turtle2
            ROS_INFO("子坐标系ID = %s",tfs.child_frame_id.c_str());//turtle1
            ROS_INFO("turtle1 相对于 turtle2 的坐标关系:(x=%.2f,y=%.2f,z=%.2f)",
                    tfs.transform.translation.x,
                    tfs.transform.translation.y,
                    tfs.transform.translation.z
                    ); */
        
        // B.根据相对关系计算并组织速度消息
        geometry_msgs::Twist twist;
        /* 
            只需要设置线速度的x和角速度的z
            x = 系数 * 开方(x的平方+y的平方)
            z = 系数 * 反正切(对边y，邻边x)
         */
        twist.linear.x = 0.5 * sqrt(pow(tfs.transform.translation.x,2) + pow(tfs.transform.translation.y,2));
        twist.angular.z = 4 * atan2(tfs.transform.translation.y,tfs.transform.translation.x); 

        // C.发布
        pub.publish(twist);

        }
        catch(const std::exception& e)
        {
            ROS_INFO("异常信息:%s",e.what());
        }


        r.sleep();
        // 6.spin
        ros::spinOnce();
    }
    return 0;
}