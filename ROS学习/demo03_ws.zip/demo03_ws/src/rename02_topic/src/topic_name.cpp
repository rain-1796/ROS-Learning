#include "ros/ros.h"
#include "std_msgs/String.h"

int main(int argc, char *argv[])
{
    ros::init(argc,argv,"hello");
    //ros::NodeHandle nh;

    //启动节点时，传递一个命名空间 __ns:= xxx 

    /* 1.全局话题 格式:以/开头的话题名称，和节点名称无关*/
    //ros::Publisher pub=nh.advertise<std_msgs::String>("/chatter",1000);
    //ros::Publisher pub=nh.advertise<std_msgs::String>("/AAA/chatter",1000);

    /* 2.相对话题 格式:非/开头的话题名称,参考命名空间(与节点名称平级)来确定话题名称 */
    //ros::Publisher pub=nh.advertise<std_msgs::String>("chatter",1000);
    //ros::Publisher pub=nh.advertise<std_msgs::String>("AAA/chatter/",1000);

    /* 3.私有话题 使用节点句柄 “~”，生成的话题都是私有话题*/
    ros::NodeHandle nh("~");
    //ros::Publisher pub=nh.advertise<std_msgs::String>("chatter",1000);
    //ros::Publisher pub=nh.advertise<std_msgs::String>("AAA/chatter",1000);
    
    
    //但是如果话题名称最开始有"/"，生成的话题是全局话题
    ros::Publisher pub=nh.advertise<std_msgs::String>("/AAA/chatter",1000);
    /* 死循环，避免节点关闭 */
    while (ros::ok())
    {
        
    }
    
    return 0;
}
