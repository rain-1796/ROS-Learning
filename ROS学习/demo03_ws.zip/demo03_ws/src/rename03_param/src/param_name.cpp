#include "ros/ros.h"

int main(int argc, char *argv[])
{
    ros::init(argc,argv,"hello");
    ros::NodeHandle nh;

    /* 使用 ros::param 来创建参数 */
    //1.全局参数
    ros::param::set("/radiusA",100);
    //2.相对参数
    ros::param::set("radiusA",10);
    //3.私有参数
    ros::param::set("~radiusA",1);

    /* 使用 Nodehandle 来创建参数 */
    //1.全局参数
    nh.setParam("/radius_nh",500);
    //2.相对参数
    nh.setParam("radius_nh",50);
    //3.私有参数
    ros::NodeHandle nh_private("~");
    nh_private.setParam("rsdius_nh",5);
    return 0;
}
