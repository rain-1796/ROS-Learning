#ifndef _HAHA_H
#define _HAHA_H

namespace hello_ns {

class My {

public:
    void run(); //run函数的声明

};

}

#endif
