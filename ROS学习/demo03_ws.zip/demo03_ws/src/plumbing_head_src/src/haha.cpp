#include "plumbing_head_src/haha.h"
#include "ros/ros.h"

namespace hello_ns{

//run函数的定义
void My::run()
{
    ROS_INFO("hello,head and src ...");
}

}
