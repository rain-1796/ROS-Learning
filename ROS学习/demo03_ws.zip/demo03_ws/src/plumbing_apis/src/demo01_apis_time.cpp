#include "ros/ros.h"

//回调函数
void doSomeThing(const ros::TimerEvent &event){
    ROS_INFO("-------------");
    ROS_INFO("函数被调用的时刻:%.2f",event.current_real.toSec());
}


int main(int argc, char *argv[])
{
    //防止中文乱码
    setlocale(LC_ALL,"");
    ros::init(argc,argv,"hello_time");
    ros::NodeHandle nh;//必须创建句柄，否则时间没有初始化，导致后续API调用失败

// ---------------------时刻----------------------------------------------
    //获取当前时刻
    ros::Time right_now = ros::Time::now();//将当前时刻封装成对象
    ROS_INFO("当前时刻:%.2f",right_now.toSec());//获取距离 1970年01月01日 00:00:00 的秒数
    ROS_INFO("当前时刻:%d",right_now.sec);//获取距离 1970年01月01日 00:00:00 的秒数

    //获取指定时刻
    ros::Time someTime(100,100000000);// 参数1:秒数  参数2:纳秒
    ROS_INFO("时刻:%.2f",someTime.toSec()); //100.10
    ros::Time someTime2(100.3);//直接传入 double 类型的秒数
    ROS_INFO("时刻:%.2f",someTime2.toSec()); //100.30

// ------------------------持续时间----------------------------------------
    ROS_INFO("当前时刻:%.2f",ros::Time::now().toSec());

    ros::Duration du(10);//持续10秒钟,参数是double类型的，以秒为单位
    du.sleep();//按照指定的持续时间休眠

    ROS_INFO("持续时间:%.2f",du.toSec());//将持续时间换算成秒
    ROS_INFO("当前时刻:%.2f",ros::Time::now().toSec());

// ------------------------持续时间与时刻运算-------------------------------
    ROS_INFO("时间运算");
    ros::Time now = ros::Time::now();
    ros::Duration du1(5);
    ros::Duration du2(10);
    ROS_INFO("当前时刻:%.2f",now.toSec());
    //1.time 与 duration 运算
    ros::Time after_now = now + du1;
    ros::Time before_now = now - du1;
    ROS_INFO("当前时刻之后:%.2f",after_now.toSec());
    ROS_INFO("当前时刻之前:%.2f",before_now.toSec());

    //2.duration 之间相互运算
    ros::Duration du3 = du1 + du2;
    ros::Duration du4 = du1 - du2;
    ROS_INFO("du3 = %.2f",du3.toSec());
    ROS_INFO("du4 = %.2f",du4.toSec());

    //3.time 与 time 不可以相加，但是可以相减，只不过是duration类型
    // ros::Time nn = now + before_now;//异常
    ros::Duration du5 = after_now - before_now;
    ROS_INFO("两个时刻相减:du5 = %.2f",du5.toSec());

// ---------------------------设置运行频率----------------------------
    // ros::Rate rate(0.5);//指定频率
    // while (true)
    // {
    //     ROS_INFO("-----------code----------");
    //     rate.sleep();//休眠，休眠时间 = 1 / 频率。 //在这里休眠时间为2，也就是发一条休息2秒
    // }

// ----------------------------定时器---------------------------------
    ROS_INFO("定时器");
    
   /*  ros::Timer createTimer(ros::Duration period, //时间间隔
                            const ros::TimerCallback &callback, //回调函数
             默认：          bool oneshot = false, //是否为一次性，true表示只执行一次回调函数，false表示循环执行回调函数
                            bool autostart = true); //true为自动启动，false不启动，需要手动启动
    */
   // timer.start(); //手动启动
    ros::Timer timer = nh.createTimer(ros::Duration(2),doSomeThing);//只执行一次

    ros::spin(); //必须有spin（）才能循环回调

    return 0;
}
