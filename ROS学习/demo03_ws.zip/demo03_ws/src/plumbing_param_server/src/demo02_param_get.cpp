/*
    参数服务器操作之查询_C++实现:
    在 roscpp 中提供了两套 API 实现参数操作
    ros::NodeHandle

        param(键,默认值) 
            存在，返回对应结果，否则返回默认值

        getParam(键,存储结果的变量)
            存在,返回 true,且将值赋值给参数2
            如果键不存在，那么返回值为 false，且不为参数2赋值

        getParamCached(键,存储结果的变量)--提高变量获取效率
            存在,返回 true,且将值赋值给参数2
            如果键不存在，那么返回值为 false，且不为参数2赋值

        getParamNames(std::vector<std::string>)
            获取所有的键,并存储在参数 vector 中 

        hasParam(键)
            是否包含某个键，存在返回 true，否则返回 false

        searchParam(参数1，参数2)
            搜索键，参数1是被搜索的键，参数2存储搜索结果的变量

    ros::param ----- 与 NodeHandle 类似





*/

#include "ros/ros.h"

//实现查询操作
int main(int argc, char *argv[])
{   
    //防止中文乱码
    setlocale(LC_ALL,"");
    //初始化ROS节点
    ros::init(argc,argv,"get_param");
    //创建ROS节点句柄
    ros::NodeHandle nh;

    //NodeHandle--------------------------------------------------------

    
    // 1.param 函数
    int res1 = nh.param("nh_int",100); // 键存在，返回对应结果
    int res2 = nh.param("nh_int2",100); // 键不存在，返回默认值100
    ROS_INFO("param获取结果:%d,%d",res1,res2);

    // 2.getParam 函数  存在,返回 true,且将值赋值给参数2 如果键不存在，那么返回值为 false，且不为参数2赋值
    int nh_int_value;
    double nh_double_value;
    bool nh_bool_value;
    std::string nh_string_value;
    std::vector<std::string> stus;
    std::map<std::string, std::string> friends;

    nh.getParam("nh_int",nh_int_value);
    nh.getParam("nh_double",nh_double_value);
    nh.getParam("nh_bool",nh_bool_value);
    nh.getParam("nh_string",nh_string_value);
    nh.getParam("nh_vector",stus);
    nh.getParam("nh_map",friends);

    ROS_INFO("getParam获取的结果:%d,%.2f,%s,%d",
            nh_int_value,
            nh_double_value,
            nh_string_value.c_str(),
            nh_bool_value
            );
    for (auto &&stu : stus)
    {
        ROS_INFO("stus 元素:%s",stu.c_str());        
    }

    for (auto &&f : friends)
    {
        ROS_INFO("map 元素:%s = %s",f.first.c_str(), f.second.c_str());
    }

    // 3.getParamCached()
    nh.getParamCached("nh_int",nh_int_value);
    ROS_INFO("通过缓存获取数据:%d",nh_int_value);

    // 4.getParamNames()    获取键的列表
    std::vector<std::string> param_names1;//定义一个数组param_names1存放字符串
    nh.getParamNames(param_names1);//获取所有的键,并存储在数组中

    for (auto &&name : param_names1)//遍历该数组
    {
        ROS_INFO("名称解析name = %s",name.c_str());        
    }
    ROS_INFO("----------------------------");

    // 5.hasParam(键)
    ROS_INFO("存在 nh_int 吗? %d",nh.hasParam("nh_int"));
    ROS_INFO("存在 nh_intttt 吗? %d",nh.hasParam("nh_intttt"));

    // 6.searchParam()
    std::string key;
    nh.searchParam("nh_int",key);//参数1是被搜索的键，参数2 key 是存储搜索结果的变量
    ROS_INFO("搜索键:%s",key.c_str());

    
    // //param--------------------------------------------------------

    // // 1.param 函数
    // ROS_INFO("++++++++++++++++++++++++++++++++++++++++");
    // int res3 = ros::param::param("param_int",20); //存在
    // int res4 = ros::param::param("param_int2",20); // 不存在返回默认
    // ROS_INFO("param获取结果:%d,%d",res3,res4);

    // // 2.getParam 函数
    // int param_int_value;
    // double param_double_value;
    // bool param_bool_value;
    // std::string param_string_value;
    // std::vector<std::string> param_stus;
    // std::map<std::string, std::string> param_friends;

    // ros::param::get("param_int",param_int_value);
    // ros::param::get("param_double",param_double_value);
    // ros::param::get("param_bool",param_bool_value);
    // ros::param::get("param_string",param_string_value);
    // ros::param::get("param_vector",param_stus);
    // ros::param::get("param_map",param_friends);

    // ROS_INFO("getParam获取的结果:%d,%.2f,%s,%d",
    //         param_int_value,
    //         param_double_value,
    //         param_string_value.c_str(),
    //         param_bool_value
    //         );
    // for (auto &&stu : param_stus)
    // {
    //     ROS_INFO("stus 元素:%s",stu.c_str());        
    // }

    // for (auto &&f : param_friends)
    // {
    //     ROS_INFO("map 元素:%s = %s",f.first.c_str(), f.second.c_str());
    // }

    // // 3.getParamCached()
    // ros::param::getCached("param_int",param_int_value);
    // ROS_INFO("通过缓存获取数据:%d",param_int_value);

    // // 4.getParamNames()
    // std::vector<std::string> param_names2;
    // ros::param::getParamNames(param_names2);
    // for (auto &&name : param_names2)
    // {
    //     ROS_INFO("名称解析name = %s",name.c_str());        
    // }
    // ROS_INFO("----------------------------");

    // //has(键)
    // ROS_INFO("存在 param_int 吗? %d",ros::param::has("param_int"));
    // ROS_INFO("存在 param_intttt 吗? %d",ros::param::has("param_intttt"));

    // //search()
    // std::string key;
    // ros::param::search("param_int",key);
    // ROS_INFO("搜索键:%s",key.c_str());

    return 0;
}
