/*
    注意命名空间的使用。
    设置乌龟的背景颜色，需要重启乌龟GUI节点才能生效。

*/
#include "ros/ros.h"


int main(int argc, char *argv[])
{
    //初始化ROS节点
    ros::init(argc,argv,"change_color");
    //创建节点句柄
    ros::NodeHandle nh("turtlesim");
    //ros::NodeHandle nh;

    nh.setParam("background_r",255);
    nh.setParam("background_g",255);
    nh.setParam("background_b",255);

    //使用ros::param 不需要创建节点句柄
    // ros::param::set("/turtlesim/background_r",0);
    // ros::param::set("/turtlesim/background_g",0);
    // ros::param::set("/turtlesim/background_b",0);


    return 0;
}
