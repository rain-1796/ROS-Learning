#include "ros/ros.h"
#include "plumbing_head/hello.h"

namespace hello_ns 
{
    //run函数的定义
void MyHello::run()
{
    ROS_INFO("run函数执行...");
}
}

int main(int argc, char *argv[])
{
    //防止中文乱码
    setlocale(LC_ALL,"");
    ros::init(argc,argv,"test_head_node");

    //run函数的调用
    hello_ns::MyHello myhello;
    myhello.run();
    return 0;
}
