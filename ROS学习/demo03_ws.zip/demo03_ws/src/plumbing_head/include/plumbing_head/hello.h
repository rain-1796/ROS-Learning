#ifndef _HELLO_H //避免头文件重复定义
#define _HELLO_H

namespace hello_ns{

class MyHello {

public:
    void run();//run函数的声明
};

}

#endif
