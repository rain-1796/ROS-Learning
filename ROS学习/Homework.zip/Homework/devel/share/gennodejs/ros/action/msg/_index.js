
"use strict";

let AddIntsFeedback = require('./AddIntsFeedback.js');
let AddIntsActionFeedback = require('./AddIntsActionFeedback.js');
let AddIntsResult = require('./AddIntsResult.js');
let AddIntsGoal = require('./AddIntsGoal.js');
let AddIntsAction = require('./AddIntsAction.js');
let AddIntsActionGoal = require('./AddIntsActionGoal.js');
let AddIntsActionResult = require('./AddIntsActionResult.js');

module.exports = {
  AddIntsFeedback: AddIntsFeedback,
  AddIntsActionFeedback: AddIntsActionFeedback,
  AddIntsResult: AddIntsResult,
  AddIntsGoal: AddIntsGoal,
  AddIntsAction: AddIntsAction,
  AddIntsActionGoal: AddIntsActionGoal,
  AddIntsActionResult: AddIntsActionResult,
};
