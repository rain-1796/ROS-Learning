#include "ros/ros.h"
#include "geometry_msgs/Twist.h"


int main(int argc, char *argv[])
{
    // 初始化ROS节点
    ros::init(argc, argv, "turtlebot3_rectangle_move");
    ros::NodeHandle n;

    // 创建一个Publisher，发布类型为geometry_msgs/Twist的消息
    ros::Publisher twist_pub = n.advertise<geometry_msgs::Twist>("cmd_vel", 10);

    // 设置运行频率
    ros::Rate loop_rate(1);  // 每秒1次循环

    // 定义速度命令
    geometry_msgs::Twist move_cmd;

    // 矩形的边长（单位：米）
    double length = 2.0;  // 长边
    double width = 1.0;   // 短边

    // 控制机器人沿矩形路径行驶
    while (ros::ok())
    {
        // 机器人沿长边行驶
        move_cmd.linear.x = 0.2;  // 前进速度
        move_cmd.angular.z = 0.0; // 不转弯
        for (double t = 0; t < length; t += 0.2)  // 每次行驶0.2米，直到走完一条边
        {
            twist_pub.publish(move_cmd);
            ros::Duration(1).sleep();  // 等待1秒钟
        }

        // 机器人右转90度
        move_cmd.linear.x = 0.0;
        move_cmd.angular.z = 1.57;  // 旋转90度（1.57弧度）
        twist_pub.publish(move_cmd);
        ros::Duration(1).sleep();  // 等待1秒钟，完成转弯

        // 机器人沿短边行驶
        move_cmd.linear.x = 0.2;
        move_cmd.angular.z = 0.0;
        
        for (double t = 0; t < width; t += 0.2)  // 每次行驶0.2米，直到走完一条边
        {
            twist_pub.publish(move_cmd);
            ros::Duration(1).sleep();  // 等待1秒钟
        }

        // 机器人右转90度
        move_cmd.linear.x = 0.0;
        move_cmd.angular.z = 1.57;
        twist_pub.publish(move_cmd);
        ros::Duration(1).sleep();

        // 重复上述步骤形成矩形
    }

    return 0;
}
