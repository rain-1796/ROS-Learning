// 1.包含头文件 
#include "ros/ros.h"
#include "std_msgs/String.h"
#include "std_msgs/Int32.h"
/* 定义回调函数doMsg1（）接收整数消息 */
void doMsg1(const std_msgs::Int32::ConstPtr &msg_p1)
{
    ROS_INFO("这是订阅方收到的整数消息：%d",msg_p1->data);//设置文本的前缀
}

/* 定义回调函数doMsg2（）接受字符串消息 */
void doMsg2(const std_msgs::String::ConstPtr &msg_p2)
{
    ROS_INFO("这是订阅方收到的消息：%s",msg_p2->data.c_str());//设置文本的前缀
}

int main(int argc, char *argv[])
{
    //防止中文乱码
    setlocale(LC_ALL,"");

    /* 2.初始化ROS节点 (命名唯一) */
    ros::init(argc,argv,"listener");

    /* 3.实例化ROS节点句柄 */
    ros::NodeHandle nh;

    /* 4.实例化订阅者对象 */
    ros::Subscriber sub1 = nh.subscribe<std_msgs::Int32>("Counter",10,doMsg1);//接收整数消息
    ros::Subscriber sub2 = nh.subscribe<std_msgs::String>("String",10,doMsg2);//接收字符串消息
    
    /* 5.设置循环调用doMsg() */
    ros::spin();//循环读取接收的数据，并调用回调函数doMsg()处理

    return 0;
}
