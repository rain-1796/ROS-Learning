/* 1.包含头文件 */
#include "ros/ros.h"
#include "std_msgs/Int32.h" 

int main(int argc, char *argv[])
{
    //防止中文乱码
    setlocale(LC_ALL,"");

    /* 2.初始化ROS节点 (命名唯一) */
    ros::init(argc,argv,"talker1");

    /* 3.实例化ROS节点句柄 */
    ros::NodeHandle nh;

    /* 4.实例化发布者对象 */
    ros::Publisher pub = nh.advertise<std_msgs::Int32>("Counter",10);//共享话题，命名唯一

    /* 5.组织被发布的数据，并编写逻辑发布数据 */
    
    /* 创建一个Int32类型的消息 */
    std_msgs::Int32 msg;
    int count = 1;//给消息计数器赋初值

    /* 频率：一秒一次 */
    ros::Rate r(1);

    /* 循环发布 */
    while(ros::ok())//节点不死
    {
        /* 给msg.data赋值 */
        msg.data = count;
        
        /* 发布消息 */
        pub.publish(msg);

        /* 设置文本的前缀 */
        ROS_INFO("%d", msg.data);  
       
        /* 自动休眠 休眠时间=1/频率 */
        r.sleep();
        
        count++;//循环结束前，让 count 自增
        
        /* 暂无应用 */
        ros::spinOnce();
    }

    return 0;
}
