/*
    需求: 
        编写两个节点实现服务通信，客户端节点需要提交两个整数到服务器
        服务器需要解析客户端提交的数据，相加后，将结果响应回客户端，
        客户端再解析
*/

//1.包含头文件
#include "ros/ros.h"
#include "server_client/AddInts.h"

//回调函数doReq()
//返回的布尔值标志着是否处理成功
bool doReq(server_client::AddInts::Request &req,//声明了一个名为 req 的变量，它是 Request 类型的一个引用。
          server_client::AddInts::Response &resp)
{
    //处理请求
    int num1 = req.num1;
    int num2 = req.num2;
    ROS_INFO("服务器接收到的请求数据为:num1 = %d, num2 = %d",num1, num2);

    //逻辑处理
    if (num1 < 0 || num2 < 0)
    {
        ROS_ERROR("提交的数据异常:数据不可以为负数");
        return false;
    }

    //如果没有异常，那么相加并将结果赋值给 resp
    int sum = num1 + num2;
    resp.sum = sum;

    return true;

}

int main(int argc, char *argv[])
{
    //防止中文乱码
    setlocale(LC_ALL,"");
    // 2.初始化 ROS 节点
    ros::init(argc,argv,"AddInts_Server");
    // 3.创建 ROS 句柄
    ros::NodeHandle nh;
    // 4.创建 服务 对象
    ros::ServiceServer server = nh.advertiseService("AddInts",doReq);//共享服务AddInts，回调函数doReq
    
    ROS_INFO("服务已经启动....");
    //     5.回调函数处理请求并产生响应
    //     6.由于请求有多个，需要调用 ros::spin()
    ros::spin();

    return 0;
}
